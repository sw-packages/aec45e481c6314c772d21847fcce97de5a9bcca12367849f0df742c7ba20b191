﻿/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#include <aws/sqs/SQSEndpointProvider.h>

namespace Aws
{
namespace SQS
{
namespace Endpoint
{
} // namespace Endpoint
} // namespace SQS
} // namespace Aws
